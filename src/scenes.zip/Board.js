import React, { Component } from 'react';
import Button from '../components/Button'
import Modal from 'react-native-modal'
import API from '../services/API'
import PressModal from '../components/PressModal'
import {
    StyleSheet,
    Text,
    View,
    ScrollView,
    Alert,
    Dimensions,
    TextInput,
    TouchableNativeFeedback,
    ToastAndroid,
    FlatList,
    TouchableOpacity,
    Vibration
} from 'react-native';
const {width,height} = Dimensions.get('window');

class Board extends Component{
    constructor(props){
        super(props);
        this.state = {
            selectedEmotions: [], // [{emotion:'',value:0} ...]
            modalVisible:false,
            refreshing : false,
            comment:'',
            BoardName : "",
            BoardUrl : "",
            BoardData : "",
            addressData : [],
            allData : [],
            sortData : [],
        }
    }
    componentWillMount(){
        this.getData()
    }
//!FIXME :: once -> on ?
    getData(){
        this.setState({refreshing:true})
        let ref = `users`
        API.getDataOnce(ref)
            .then( (data) => {
                let items = []
                if(data.val()){
                    const obj = data.val()
                    const keys = Object.keys(obj).sort().reverse()
                    for(let i = 0, item; item = obj[keys[i]]; i++){
                        let temp = keys[i]
                        item.time = temp;
                        items.push(item)
                    }
                }
                this.setState({sortData:items})
            })
    }

    send_Data(BoardName, BoardUri) {
        var tmp = BoardUri.split("")
        var i = parseInt(tmp[0])
        if(i == 3 || i == 6 || i == 7 && i != null){
            var headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
            }
            var params = {
                id:"jje9302",
                name: BoardName,
                uri : BoardUri,
            };
            var url = "http://49.161.111.188:8080/boards"
            var formData = new FormData();
            for (var k in params) {
                formData.append(k, params[k]);
            }
            var request = {
                method: 'POST',
                headers: headers,
                body: formData
            };
            fetch(url, request)

            {this.input_data(BoardName, BoardUri)}
            alert("성공")
        }else{
            alert("Uri를 확인해주세요.")
        }
    }

    input_data(name, uri){
        let address = `${Date.now()}`;
        let ref = `users/`+address;
        //this.state.addressData.push(address);
        console.log("addressdata : ", this.state.addressData)
        console.log("addressdata : ", this.state.addressData.length)

        let data = {
            BoardName : name,
            BoardUrl : uri,
        }

        API.writeData(ref,data)
            .then(()=> {
                this.toast();
                this.setState({modalVisible:false},()=>this.getData())
            })
            .catch( (err) => Alert.alert("에러발생",err.message)).then(this.getData())

    }

    toast(){
        ()=>{ // record scenes state reset
            ToastAndroid.show('기록되었습니다.',ToastAndroid.SHORT);
        }
    }

    refresh(){
        this.setState({refreshing: false})
    }

    render(){
        return(
            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>

                <View style={{position: "absolute", bottom: 30}}>
                    <Button
                        title="게시판 추가"
                        onClick={() => this.show_modal()}/>
                </View>

                <View style={{height: 550, marginTop: -70}}>
                    <HistoryRow
                        data = {this.state.sortData}
                        info = {this.state.refreshing}
                        refresh = {()=>this.refresh()}/>
                </View>

                <InsertModal
                    modalVisible={this.state.modalVisible}
                    closeModal={() => this.close_modal()}
                    onClick={(name, url) => this.send_Data(name, url)}
                />
            </View>
        )
    }

    show_modal(){
        this.setState({modalVisible:true})
    }
    close_modal(){
        this.setState({modalVisible:false})
    }
}
export default Board;


class InsertModal extends Component{
    constructor(props){
        super(props)
        this.state={
            comment:'',
            BoardName : "",
            BoardUri : "",
            check : false,
        }
    }

    render(){
        return(
            <Modal
                isVisible={this.props.modalVisible}
                onBackButtonPress={this.props.closeModal}
                hideOnBack={true}>

                <View style ={{justifyContent:'center',alignItems:'center',backgroundColor:'#efefef'}}>
                    <Text style ={{fontSize:16,height:30, marginTop:10}}>게시판 추가</Text>
                    <View style ={{backgroundColor:"#fff", width:320}}>
                        <View style ={{width: 310,flexDirection: "row"}}>
                            <Text style={{marginTop:30}}>게시판 이름 : </Text>
                            <TextInput
                                style ={{width:230,height:40,margin:20,marginLeft: 5, borderWidth:1}}
                                multiline = {true}
                                value={this.state.BoardName}
                                onChangeText={(name)=>{this.setState({BoardName:name})}}
                                underlineColorAndroid='#fff'
                                textAlignVertical='top'/>
                        </View>
                        <View style ={{width:310,flexDirection: "row"}}>
                            <Text style={{marginTop:30}}>게시판 주소 : </Text>
                            <TextInput
                                style ={{width:230,height:40,margin:20,marginLeft:5,borderWidth:1}}
                                multiline = {true}
                                value={this.state.BoardUri}
                                onChangeText={(url)=>{this.setState({BoardUri:url})}}
                                underlineColorAndroid='#fff'
                                textAlignVertical='top' />
                        </View>
                    </View>
                    <View style={{backgrundColor:'#00000099',height:50,width:500,alignItems:'center',justifyContent:'center', flexDirection: 'row', }}>
                        <View style={{padding:15}}>
                            <Button
                                onClick={()=>{this.props.onClick(this.state.BoardName, this.state.BoardUri, this.state.check); this.setState({BoardUri:'', BoardName : ""})}}
                                buttonStyle={{width:100}}
                                title = "추가하기">
                            </Button>
                        </View>
                        <View style={{padding:15}}>
                            <Button
                                onClick={this.props.closeModal}
                                buttonStyle={{width:100}}
                                title ="취소">
                            </Button>
                        </View>
                    </View>
                </View>
            </Modal>
        )
    }


}

class HistoryRow extends Component {
    constructor(props){
        super(props)
        this.state = {
            modalVisible : false,
            selectedData : null,
            sortData : [],
            refreshing : false,

        }
    }

    componentWillMount(){
        this.getData()
    }

//!FIXME :: once -> on ?
    getData(){
        this.setState({refreshing:true})
        let ref = `users`
        API.getDataOnce(ref)
            .then( (data) => {
                let items = []
                if(data.val()){
                    const obj = data.val()
                    const keys = Object.keys(obj).sort().reverse()
                    for(let i = 0, item; item = obj[keys[i]]; i++){
                        let temp = keys[i]
                        item.time = temp;
                        items.push(item)
                    }
                }
                this.setState({sortData:items})
                console.log("alldata : ", this.state.sortData)
            })
        this.setState({refreshing: false})
    }

    renderStateBar(){
        let backgroundColor='#ff888844'
        return(
            <View style={{width:20,height:6,backgroundColor:backgroundColor}}/>
        )
    }

    render(){
        return(
            <View style = {{height:450,marginTop:45}}>
                <FlatList
                    data = {this.state.sortData}
                    style={{}}
                    renderItem = {({item}) =>
                        <View style={{borderBottomWidth:1,borderBottomColor:'#efefef'}}>
                            <TouchableOpacity
                                style={styles.rowContainer}
                                onLongPress = {()=>this.show_modal(item.time)}>
                                <View style={{width : width}}>
                                    {this.renderStateBar()}
                                    <Text style={styles.dateText}>게시판 이름 : {item.BoardName}</Text>
                                    <Text style={styles.timeText}>게시판 URL : {item.BoardUri}{"\n"}{"\n"}</Text>
                                </View>
                            </TouchableOpacity>
                        </View>
                    }
                />
                <PressModal
                    modalVisible = {this.state.modalVisible}
                    onClose = {()=>this.close_modal()}
                    onClick = {()=>this.onRemove()}
                    label = "삭제하기"
                />
            </View>
        );
    }
    show_modal(key){
        this.setState({selectedData:key,modalVisible:true},()=>Vibration.vibrate([0,80]))
    }

    close_modal(){
        this.setState({modalVisible:false})
    }

    onRemove(){
        let ref = `users`
        API.removeData(ref,this.state.selectedData);
        this.setState({modalVisible:false},()=>this.getData())
        ToastAndroid.show('삭제되었습니다',ToastAndroid.SHORT)
    }
}


const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'space-between',
        alignItems: 'center',
        backgroundColor: 'white',
    },
    flexRight: {
        alignSelf:'flex-end',
    },
    rowContainer:{
        flexDirection: 'row',
        paddingLeft:15,
        paddingRight:15,
        alignItems:'center',
    },
    leftWrapper:{
        flex:1,
        flexDirection:'row' ,
    },
    leftText:{
        fontSize:13,
    },
    midWrapper:{
        flex:1,
        alignItems:'flex-start',
        paddingRight:0
    },
    midText:{
        fontSize:22,
        color:'#444444',

    },
    rightWrapper:{
        flex:1,
        alignItems:'flex-end',
    },
    rightItems:{
        alignItems:'center',
    },
    dateText:{
        fontSize:12,
        color:'#666666',
    },
    timeText:{
        fontSize:13,
        color:'#8f8f8f'
    },
})